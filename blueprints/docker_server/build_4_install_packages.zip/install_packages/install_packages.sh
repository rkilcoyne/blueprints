#!/bin/bash
PACKAGES="{{ PACKAGES_TO_INSTALL }}"
yum install -y $PACKAGES

